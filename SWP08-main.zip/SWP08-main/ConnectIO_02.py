
# Attempting SWP08 control
# let's start with building a connection

# SWP08 protocol info:
# https://wwwapps.grassvalley.com/docs/Manuals/sam/Protocols%20and%20MIBs/Router%20Control%20Protocols%20SW-P-88%20Issue%204b.pdf

import time

from connection_01 import Connection
from swp08_01 import Message

if __name__ == '__main__':

    print(20 * '#' + ' ConnectIO - SWP08 router controller ' + 20 * '#')

    #address = "172.29.1.24"     # Impulse default Router Management adapaptor
    address = "192.169.1.201"    # Impulse added address for Router on Interface 3
    port = 61000  # Fixed port for SWP08

    # Open a TCP connection with the mixer/router
    connection = Connection(address, port)
    time.sleep(2)

    # Test message - connect source 0 to destination 10
    test1 = Message.connect(0, 10)
    print("Test message:", test1)

    # Sample message from mixer - Connected
    test_message = b'\x10\x02\x04\x00\x00\n\x00\x05\xed\x10\x03'
    test2 = Message.decode(test_message)
    print("Test decoding:", test2)

    connection.send(test1)

    i = 0
    while True:
        print('\n', i, 'qty:', len(connection.messages), 'residual data', connection.residual_data)
        
        for message in connection.messages:
            print("message recieved:")
            print(message)
            print ("len", len(message))
            for ch in message:
                print(ch, end=" - ")

        i += 1
        time.sleep(2)


