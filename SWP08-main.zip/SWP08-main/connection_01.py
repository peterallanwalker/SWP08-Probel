# CONNECTION
# IP connection manager, buffers incoming messages, provides send and receive methods
# Peter Walker, June 2021

# Based on CSCP_connection, let's aim to keep it generic, with SWP08 specific handling external to this file.

import socket
import threading

TIMEOUT = 3  # how long to wait when starting connection and receiving data.
RECEIVE_TIMEOUT = 10


class Connection:

    def __init__(self, address, port):

        self.address = address
        self.port = port
        #self.sock = False
        self.sock = None
        self.status = 'Starting'

        self.messages = []
        self.residual_data = False  # Residual data that cannot be parsed but might be the beginning of a message
        # whose remainder is in the next data to be received

        # self.connect()
        self.receiver = threading.Thread(target=self.run)
        self.receiver.daemon = True  # trying this, should cause thread to stop if main program stops, I.E. control+C to release the terminal
        self.receiver.start()

    def connect(self):
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.settimeout(TIMEOUT)
            self.sock.connect((self.address, self.port))
            print('connection: IP connection established with address {} on port {}'.format(self.address, self.port))

            # I just have to send any message, not this one specifically)
            # TODO - ping device / request some data
            self.status = "Connected"

        except socket.timeout:
            print('Connection: Failed to create connection with address {} on port {}'.format(self.address, self.port))
            self.close()
            #self.sock = False
            self.sock = None

    def run(self):

        # if not connected, try to create a socket connection.
        while not self.sock:
            if not self.status == 'Connection Lost!':
                self.status = 'Not Connected'
            self.connect()

        # TODO - test this - if sock.recv timesout does that kill sock, will I still be able to get messages recieved in interim before next call to recv?
        # - this might be causing messages to be missed, faders seem a bit jittery since doing this.

        self.sock.settimeout(RECEIVE_TIMEOUT)
        loop = 0
        self.pinged = False
        while True:
            try:
                data = self.sock.recv(1024)
                # TODO - experiment setting value very small to see if I can split messages and test unpack's residual data
            except:
                data = False

            # print('CSCP_connection run: data received', data, 'pinged', self.pinged)

            if data:
                self.pinged = False
                print(data)
                self.messages.append(data)  # TODO - parse before storing, and create a get method.

            elif self.pinged:
                self.status = "Connection Lost!"
                self.close()
                self.connect()
                self.run()

    def send(self, message):
        try:
            self.sock.sendall(message)
        except:
            pass

    def receive(self):
        """ Check Receive Buffer """
        self.sock.settimeout(None)
        data = self.sock.recv(1024)
        return data

    # TODO - dont think I'm using this, check proper behaviour for handling sockets and threads
    def close(self):
        self.sock.close
        try:
            self.receiver.stop()
        except:
            pass


if __name__ == '__main__':
    print(20 * '#' + ' IP Connection Manager' + 20 * '#')

    # address = "172.29.1.24"  # Impulse default SWP08 Router Management adaptor
    address = "192.169.1.201"  # Impulse added address for SWP08 Router on Interface 3

    port = 61000  # Fixed port for SWP08

    # Open a TCP connection with the mixer/router
    connection = Connection(address, port)

    while True:
        pass